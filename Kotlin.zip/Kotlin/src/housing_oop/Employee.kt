package housing_oop

data class Employee(val name: String, val age: Int)
