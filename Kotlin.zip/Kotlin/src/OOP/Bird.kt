package OOP

class Bird: Animal("Bird", 2) {

    override fun makeSound() {

        println("Chirp chirp... a little singing, chirp...")
        println("[swiftly flies away]")
    }
}