package OOP

class Cat: Animal("Cat", 3) {

    override fun makeSound() {

        println("Meeoow...")
        println("[Drops stuff off the table]")
    }
}