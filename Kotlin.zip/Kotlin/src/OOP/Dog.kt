package OOP

class Dog: Animal("Dog") {

    override fun makeSound() {

        println("Woof!!!")
    }
}