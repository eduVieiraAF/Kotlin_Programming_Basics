@file:JvmName("InterpFish")

package aquarium

class InteropFish {

    companion object{

        @JvmStatic fun interop(){

        }
    }
}