package aquarium;

public class JavaRun {

    public static void runNow(Runnable runnable){

        runnable.run();
    }
}
