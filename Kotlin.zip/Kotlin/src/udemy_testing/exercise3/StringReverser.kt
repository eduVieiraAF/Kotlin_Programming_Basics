package udemy_testing.exercise3

class StringReverser {
    fun reverse(string: String) = string.reversed()
}