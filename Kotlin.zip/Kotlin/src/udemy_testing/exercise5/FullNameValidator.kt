package udemy_testing.exercise5

class FullNameValidator {
    fun isValidFullName(fullName: String): Boolean {
        return fullName.isNotEmpty()
    }
}