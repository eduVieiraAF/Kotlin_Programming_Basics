package udemy_testing.exercise4.eventbus

class LoggedInEvent {
}