package udemy_testing.exercise4.networking

class NetworkErrorExceptions: Exception() {
}