package udemy_testing.exercise2

class PositiveValidator {
    fun isPositive(num: Int): Boolean {
        return num > 0
    }
}