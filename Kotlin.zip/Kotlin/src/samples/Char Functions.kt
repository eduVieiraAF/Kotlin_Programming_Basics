package samples

fun main() {

    val char = 'a'

    println(char.isDigit())
    println(char.isLetter())
    println(char.isLetterOrDigit())
    println(char.isWhitespace())
    println(char.isLowerCase())
    println(char.isUpperCase())
    println(char.uppercaseChar())
    println(char.lowercaseChar())
    println(char.uppercase())
    println(char.lowercase())

}