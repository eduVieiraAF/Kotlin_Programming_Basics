package samples

fun main() {

    val number = readln().toCharArray()
    println(number.reversedArray())
}




