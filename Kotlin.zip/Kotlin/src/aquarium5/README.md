
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpM9j3Y1K8coolE7PhVzu9U_r-X1HLNZGswQ&usqp=CAU" width="200" height="110"/>

## UDACITY KOTLIN BASICS COURSE

- ###  The files were based on a course provided by Udacity. 