<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpM9j3Y1K8coolE7PhVzu9U_r-X1HLNZGswQ&usqp=CAU" width="300" height="168"/>

##  Samples of my learning material and tests.
- ### In here, there are sample codes and code I've written based on stuff I found on:
    -  YouTube's tutorials;
    -  Udacity Kotlin course;
    -  Codelabs;
    -  JetBrains Academy tracks;
    -  udemy_testing testing course.
